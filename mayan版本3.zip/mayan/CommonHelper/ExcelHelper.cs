﻿using System.Data;
using System.IO;
using System.Web;
using System.Web.UI.WebControls;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;

namespace Mayan.CommonHelper
{
    public class ExcelHelper
    {
        private static XSSFWorkbook ExportExcel(GridView gridview)
        {
            XSSFWorkbook workbook = new XSSFWorkbook();
            XSSFSheet sheet = workbook.CreateSheet("sheet1") as XSSFSheet;
            XSSFRow headerrow = sheet.CreateRow(0) as XSSFRow;
            XSSFRow row;
            XSSFCell cell;
            #region 设定表头行
            for (int i = 0; i < gridview.HeaderRow.Cells.Count; i++)
            {
                cell = headerrow.CreateCell(i) as XSSFCell;
                cell.SetCellValue(gridview.HeaderRow.Cells[i].Text.ToString());
                cell.SetCellType(CellType.STRING);
            } 
            #endregion
            int RowCount = gridview.Rows.Count;//得到gridview里面的行数
            for (int i = 1; i <= RowCount;i++ )
            {
                row = sheet.CreateRow(i) as XSSFRow;
                for (int j = 0; j < gridview.Rows[i].Cells.Count;j++ )
                {
                    cell = row.CreateCell(j) as XSSFCell;
                    cell.SetCellValue(gridview.Rows[i].Cells[j].Text.ToString().Trim());
                    cell.SetCellType(CellType.STRING);
                }
            }
           
            return workbook;
        }
        public static DataTable LeadingExcel(Stream stream)
        {
            //根据数据流创建一个excel对象
            XSSFWorkbook workbook = new XSSFWorkbook(stream);
            //获取excel里面的第一个sheet
            XSSFSheet sheet = workbook.GetSheetAt(0) as XSSFSheet;
            //定义一个DataTable，用来存储 excel里面的数据
            DataTable table = new DataTable();
            //得到excel里面的第一行
            XSSFRow headerRow = sheet.GetRow(0) as XSSFRow;
            //得到excel的列数 ，从1开始计数，就是有几列LastCellNum的值就为几
            int cellCount = headerRow.LastCellNum;
            for (int i = headerRow.FirstCellNum; i < cellCount; i++) //FirstCellNum表示第一个单元格值为0
            {
                DataColumn column = new DataColumn(headerRow.GetCell(i).StringCellValue);
                table.Columns.Add(column);
            }
            // 即总的行数从0开始计数 ，LastRowNum的值等于总行数减一
            int rowCount = sheet.LastRowNum;
            for (int i = (sheet.FirstRowNum + 1); i <= sheet.LastRowNum; i++)  //FirstRowNum表示第一行值为0
            {
                XSSFRow row = sheet.GetRow(i) as XSSFRow;
                DataRow dataRow = table.NewRow();
                for (int j = row.FirstCellNum; j < cellCount; j++)
                {
                    if (row.GetCell(j) != null)
                        dataRow[j] = row.GetCell(j).ToString();
                }
                table.Rows.Add(dataRow);
            }
            workbook = null;
            sheet = null;
            return table;
        }
        public static void RenderToBrowser(XSSFWorkbook workbook, HttpContext context, string fileName)
        {
            MemoryStream stream = new MemoryStream();
            workbook.Write(stream);
            if (context.Request.Browser.Browser == "IE")
                fileName = HttpUtility.UrlEncode(fileName);
            context.Response.AddHeader("Content-Disposition", "attachment;fileName=" + fileName);
            context.Response.BinaryWrite(stream.ToArray());
            context.Response.Flush();
        }
    }
}