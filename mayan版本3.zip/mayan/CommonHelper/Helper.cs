﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;

namespace Mayan.CommonHelper
{
    public class Helper
    {
        private static DAL.tb_StuInfo Dal_Stu = new DAL.tb_StuInfo();
        private static DAL.tb_UserAdmin Dal_Admin = new DAL.tb_UserAdmin();
        public static Model.tb_StuInfo CheckLogin(string username,string password)
        {
            Model.tb_StuInfo Model_Stu = null;
            Model_Stu = Dal_Stu.GetModel(username);
            if (Model_Stu!=null)
            {
                Model_Stu = Model_Stu.SPwd.Equals(password) ? Model_Stu : null;
            }
            return Model_Stu;
        }
        public static Model.tb_UserAdmin CheckAdminLogin(string username, string password)
        {
            Model.tb_UserAdmin Model_Admin = null;
            Model_Admin = Dal_Admin.GetModel(username);
            if (Model_Admin != null)
            {
                Model_Admin = Model_Admin.Password.Equals(password) ? Model_Admin : null;
            }
            return Model_Admin;
        }
    }
}