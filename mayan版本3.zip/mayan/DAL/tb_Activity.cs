﻿using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using Mayan.CommonHelper;

namespace Mayan.DAL
{
	/// <summary>
	/// 数据访问类:tb_Activity
	/// </summary>
	public partial class tb_Activity
	{
		public tb_Activity()
		{}
		#region  BasicMethod

		/// <summary>
		/// 是否存在该记录
		/// </summary>
		public bool Exists(Guid Id)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from tb_Activity");
			strSql.Append(" where Id=SQL2012Id ");
			SqlParameter[] parameters = {
					new SqlParameter("SQL2012Id", SqlDbType.UniqueIdentifier,16)			};
			parameters[0].Value = Id;

			return DbHelperSQL.Exists(strSql.ToString(),parameters);
		}


		/// <summary>
		/// 增加一条数据
		/// </summary>
		public bool Add(Mayan.Model.tb_Activity model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("insert into tb_Activity(");
			strSql.Append("Id,AName,AStartTime,AEndTime,AMaxNo,ACharge,AWhere,AStuNo,State,AEntryTime,AUpdateTime,APeople)");
			strSql.Append(" values (");
			strSql.Append("@SQL2012Id,@SQL2012AName,@SQL2012AStartTime,@SQL2012AEndTime,@SQL2012AMaxNo,@SQL2012ACharge,@SQL2012AWhere,@SQL2012AStuNo,@SQL2012State,@SQL2012AEntryTime,@SQL2012AUpdateTime,@SQL2012APeople)");
			SqlParameter[] parameters = {
					new SqlParameter("@SQL2012Id", SqlDbType.UniqueIdentifier,16),
					new SqlParameter("@SQL2012AName", SqlDbType.NVarChar,50),
					new SqlParameter("@SQL2012AStartTime", SqlDbType.DateTime),
					new SqlParameter("@SQL2012AEndTime", SqlDbType.DateTime),
					new SqlParameter("@SQL2012AMaxNo", SqlDbType.Int,4),
					new SqlParameter("@SQL2012ACharge", SqlDbType.NVarChar,50),
					new SqlParameter("@SQL2012AWhere", SqlDbType.NVarChar,50),
					new SqlParameter("@SQL2012AStuNo", SqlDbType.Int,4),
					new SqlParameter("@SQL2012State", SqlDbType.Int,4),
					new SqlParameter("@SQL2012AEntryTime", SqlDbType.DateTime),
					new SqlParameter("@SQL2012AUpdateTime", SqlDbType.DateTime),
					new SqlParameter("@SQL2012APeople", SqlDbType.NVarChar,50)};
			parameters[0].Value = model.Id;
			parameters[1].Value = model.AName;
			parameters[2].Value = model.AStartTime;
			parameters[3].Value = model.AEndTime;
			parameters[4].Value = model.AMaxNo;
			parameters[6].Value = model.AWhere;
			parameters[7].Value = model.AStuNo;
			parameters[8].Value = model.State;
			parameters[9].Value = model.AEntryTime;
			parameters[10].Value = model.AUpdateTime;
			parameters[11].Value = model.APeople;

			int rows=DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool Update(Mayan.Model.tb_Activity model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("update tb_Activity set ");
			strSql.Append("AName=@SQL2012AName,");
			strSql.Append("AStartTime=@SQL2012AStartTime,");
			strSql.Append("AEndTime=@SQL2012AEndTime,");
			strSql.Append("AMaxNo=@SQL2012AMaxNo,");
			strSql.Append("ACharge=@SQL2012ACharge,");
			strSql.Append("AWhere=@SQL2012AWhere,");
			strSql.Append("AStuNo=@SQL2012AStuNo,");
			strSql.Append("State=@SQL2012State,");
			strSql.Append("AEntryTime=@SQL2012AEntryTime,");
			strSql.Append("AUpdateTime=@SQL2012AUpdateTime,");
			strSql.Append("APeople=@SQL2012APeople");
			strSql.Append(" where Id=@SQL2012Id ");
			SqlParameter[] parameters = {
					new SqlParameter("@SQL2012AName", SqlDbType.NVarChar,50),
					new SqlParameter("@SQL2012AStartTime", SqlDbType.DateTime),
					new SqlParameter("@SQL2012AEndTime", SqlDbType.DateTime),
					new SqlParameter("@SQL2012AMaxNo", SqlDbType.Int,4),
					new SqlParameter("@SQL2012ACharge", SqlDbType.NVarChar,50),
					new SqlParameter("@SQL2012AWhere", SqlDbType.NVarChar,50),
					new SqlParameter("@SQL2012AStuNo", SqlDbType.Int,4),
					new SqlParameter("@SQL2012State", SqlDbType.Int,4),
					new SqlParameter("@SQL2012AEntryTime", SqlDbType.DateTime),
					new SqlParameter("@SQL2012AUpdateTime", SqlDbType.DateTime),
					new SqlParameter("@SQL2012APeople", SqlDbType.NVarChar,50),
					new SqlParameter("@SQL2012Id", SqlDbType.UniqueIdentifier,16)};
			parameters[0].Value = model.AName;
			parameters[1].Value = model.AStartTime;
			parameters[2].Value = model.AEndTime;
			parameters[3].Value = model.AMaxNo;
			parameters[5].Value = model.AWhere;
			parameters[6].Value = model.AStuNo;
			parameters[7].Value = model.State;
			parameters[8].Value = model.AEntryTime;
			parameters[9].Value = model.AUpdateTime;
			parameters[10].Value = model.APeople;
			parameters[11].Value = model.Id;

			int rows=DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		/// <summary>
		/// 删除一条数据
		/// </summary>
		public bool Delete(Guid Id)
		{
			//从tb_Activity中删除
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from tb_Activity ");
			strSql.Append(" where Id=@SQL2012Id ");
			SqlParameter[] parameters = {
					new SqlParameter("@SQL2012Id", SqlDbType.UniqueIdentifier,16)			};
			parameters[0].Value = Id;
			int rows1=DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);




            //从tb_ActRecord中删除
            StringBuilder strSql2 = new StringBuilder();
            strSql2.Append("delete from tb_ActRecord ");
            strSql2.Append(" where ActivityId=@SQL2012acId ");
            SqlParameter[] parameters2 = {
					new SqlParameter("@SQL2012acId", SqlDbType.UniqueIdentifier,16)			};
            parameters2[0].Value = Id;
            int rows2 = DbHelperSQL.ExecuteSql(strSql2.ToString(), parameters2);
			if (rows2 > 0 && rows1>0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		/// <summary>
		/// 批量删除数据
		/// </summary>
		public bool DeleteList(string Idlist )
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from tb_Activity ");
			strSql.Append(" where Id in ("+Idlist + ")  ");
			int rows=DbHelperSQL.ExecuteSql(strSql.ToString());
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}


		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Mayan.Model.tb_Activity GetModel(Guid Id)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1 Id,AName,AStartTime,AEndTime,AMaxNo,ACharge,AWhere,AStuNo,State,AEntryTime,AUpdateTime,APeople from tb_Activity ");
			strSql.Append(" where Id=@SQL2012Id ");
			SqlParameter[] parameters = {
					new SqlParameter("@SQL2012Id", SqlDbType.UniqueIdentifier,16)			};
			parameters[0].Value = Id;

			Mayan.Model.tb_Activity model=new Mayan.Model.tb_Activity();
			DataSet ds=DbHelperSQL.Query(strSql.ToString(),parameters);
			if(ds.Tables[0].Rows.Count>0)
			{
				return DataRowToModel(ds.Tables[0].Rows[0]);
			}
			else
			{
				return null;
			}
		}


		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Mayan.Model.tb_Activity DataRowToModel(DataRow row)
		{
			Mayan.Model.tb_Activity model=new Mayan.Model.tb_Activity();
			if (row != null)
			{
				if(row["Id"]!=null && row["Id"].ToString()!="")
				{
					model.Id= new Guid(row["Id"].ToString());
				}
				if(row["AName"]!=null)
				{
					model.AName=row["AName"].ToString();
				}
				if(row["AStartTime"]!=null && row["AStartTime"].ToString()!="")
				{
					model.AStartTime=DateTime.Parse(row["AStartTime"].ToString());
				}
				if(row["AEndTime"]!=null && row["AEndTime"].ToString()!="")
				{
					model.AEndTime=DateTime.Parse(row["AEndTime"].ToString());
				}
				if(row["AMaxNo"]!=null && row["AMaxNo"].ToString()!="")
				{
					model.AMaxNo=int.Parse(row["AMaxNo"].ToString());
				}
				if(row["ACharge"]!=null)
				{
					model.ACharge=row["ACharge"].ToString();
				}
				if(row["AWhere"]!=null)
				{
					model.AWhere=row["AWhere"].ToString();
				}
				if(row["AStuNo"]!=null && row["AStuNo"].ToString()!="")
				{
					model.AStuNo=int.Parse(row["AStuNo"].ToString());
				}
				if(row["State"]!=null && row["State"].ToString()!="")
				{
					model.State=int.Parse(row["State"].ToString());
				}
				if(row["AEntryTime"]!=null && row["AEntryTime"].ToString()!="")
				{
					model.AEntryTime=DateTime.Parse(row["AEntryTime"].ToString());
				}
				if(row["AUpdateTime"]!=null && row["AUpdateTime"].ToString()!="")
				{
					model.AUpdateTime=DateTime.Parse(row["AUpdateTime"].ToString());
				}
				if(row["APeople"]!=null)
				{
					model.APeople=row["APeople"].ToString();
				}
			}
			return model;
		}

		/// <summary>
		/// 获得数据列表
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select Id,AName,AStartTime,AEndTime,AMaxNo,ACharge,AWhere,AStuNo,State,AEntryTime,AUpdateTime,APeople ");
			strSql.Append(" FROM tb_Activity ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获得前几行数据
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
			strSql.Append(" Id,AName,AStartTime,AEndTime,AMaxNo,ACharge,AWhere,AStuNo,State,AEntryTime,AUpdateTime,APeople ");
			strSql.Append(" FROM tb_Activity ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获取记录总数
		/// </summary>
		public int GetRecordCount(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) FROM tb_Activity ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			object obj = DbHelperSQL.GetSingle(strSql.ToString());
			if (obj == null)
			{
				return 0;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("SELECT * FROM ( ");
			strSql.Append(" SELECT ROW_NUMBER() OVER (");
			if (!string.IsNullOrEmpty(orderby.Trim()))
			{
				strSql.Append("order by T." + orderby );
			}
			else
			{
				strSql.Append("order by T.Id desc");
			}
			strSql.Append(")AS Row, T.*  from tb_Activity T ");
			if (!string.IsNullOrEmpty(strWhere.Trim()))
			{
				strSql.Append(" WHERE " + strWhere);
			}
			strSql.Append(" ) TT");
			strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/*
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		{
			SqlParameter[] parameters = {
					new SqlParameter("SQL2012tblName", SqlDbType.VarChar, 255),
					new SqlParameter("SQL2012fldName", SqlDbType.VarChar, 255),
					new SqlParameter("SQL2012PageSize", SqlDbType.Int),
					new SqlParameter("SQL2012PageIndex", SqlDbType.Int),
					new SqlParameter("SQL2012IsReCount", SqlDbType.Bit),
					new SqlParameter("SQL2012OrderType", SqlDbType.Bit),
					new SqlParameter("SQL2012strWhere", SqlDbType.VarChar,1000),
					};
			parameters[0].Value = "tb_Activity";
			parameters[1].Value = "Id";
			parameters[2].Value = PageSize;
			parameters[3].Value = PageIndex;
			parameters[4].Value = 0;
			parameters[5].Value = 0;
			parameters[6].Value = strWhere;	
			return DbHelperSQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
		}*/

		#endregion  BasicMethod
		#region  ExtensionMethod

	    public  DataTable GetActStu(Guid Id)
	    {
	        StringBuilder str = new StringBuilder();
            str.Append("select s.Id,s.SNo,s.SName,s.SClass,s.SGender,s.SPhone,s.SPolitical,s.SCount,s.SEntryTime,s.SUpdateTime,s.SNotIn,s.SPwd,a.IsHere from tb_StuInfo as s inner join tb_ActRecord as a on s.Id=a.StuId where s.Id in(select StuId from tb_ActRecord where ActivityId=@ActivityId)");
	        SqlParameter[] para = {new SqlParameter("@ActivityId",Id)};
	        return DbHelperSQL.Query(str.ToString(), para).Tables[0];
	    }

	    #endregion  ExtensionMethod
	}
}

