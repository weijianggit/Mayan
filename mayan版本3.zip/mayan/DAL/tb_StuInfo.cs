﻿using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using Mayan.CommonHelper;

namespace Mayan.DAL
{
	/// <summary>
	/// 数据访问类:tb_StuInfo
	/// </summary>
	public partial class tb_StuInfo
	{
		public tb_StuInfo()
		{}
		#region  BasicMethod

		/// <summary>
		/// 是否存在该记录
		/// </summary>
		public bool Exists(Guid Id)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from tb_StuInfo");
			strSql.Append(" where Id=@SQL2012Id ");
			SqlParameter[] parameters = {
					new SqlParameter("@SQL2012Id", SqlDbType.UniqueIdentifier,16)			};
			parameters[0].Value = Id;

			return DbHelperSQL.Exists(strSql.ToString(),parameters);
		}


		/// <summary>
		/// 增加一条数据
		/// </summary>
		public bool Add(Mayan.Model.tb_StuInfo model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("insert into tb_StuInfo(");
			strSql.Append("Id,SNo,SName,SClass,SGender,SPhone,SPolitical,SCount,SPwd,SEntryTime,SUpdateTime,State,SNotIn)");
			strSql.Append(" values (");
			strSql.Append("@SQL2012Id,@SQL2012SNo,@SQL2012SName,@SQL2012SClass,@SQL2012SGender,@SQL2012SPhone,@SQL2012SPolitical,@SQL2012SCount,@SQL2012SPwd,@SQL2012SEntryTime,@SQL2012SUpdateTime,@SQL2012State,@SQL2012SNotIn)");
			SqlParameter[] parameters = {
					new SqlParameter("@SQL2012Id", SqlDbType.UniqueIdentifier,16),
					new SqlParameter("@SQL2012SNo", SqlDbType.NVarChar,50),
					new SqlParameter("@SQL2012SName", SqlDbType.NVarChar,50),
					new SqlParameter("@SQL2012SClass", SqlDbType.NVarChar,50),
					new SqlParameter("@SQL2012SGender", SqlDbType.Char,10),
					new SqlParameter("@SQL2012SPhone", SqlDbType.NVarChar,11),
					new SqlParameter("@SQL2012SPolitical", SqlDbType.NVarChar,50),
					new SqlParameter("@SQL2012SCount", SqlDbType.Int,4),
					new SqlParameter("@SQL2012SPwd", SqlDbType.NVarChar,50),
					new SqlParameter("@SQL2012SEntryTime", SqlDbType.DateTime),
					new SqlParameter("@SQL2012SUpdateTime", SqlDbType.DateTime),
					new SqlParameter("@SQL2012State", SqlDbType.Int,4),
					new SqlParameter("@SQL2012SNotIn", SqlDbType.Int,4)};
			parameters[0].Value = Guid.NewGuid();
			parameters[1].Value = model.SNo;
			parameters[2].Value = model.SName;
			parameters[3].Value = model.SClass;
			parameters[4].Value = model.SGender;
			parameters[5].Value = model.SPhone;
			parameters[6].Value = model.SPolitical;
			parameters[7].Value = model.SCount;
			parameters[8].Value = model.SPwd;
			parameters[9].Value = model.SEntryTime;
			parameters[10].Value = model.SUpdateTime;
			parameters[11].Value = model.State;
			parameters[12].Value = model.SNotIn;

			int rows=DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool Update(Mayan.Model.tb_StuInfo model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("update tb_StuInfo set ");
			strSql.Append("SNo=@SQL2012SNo,");
			strSql.Append("SName=@SQL2012SName,");
			strSql.Append("SClass=@SQL2012SClass,");
			strSql.Append("SGender=@SQL2012SGender,");
			strSql.Append("SPhone=@SQL2012SPhone,");
			strSql.Append("SPolitical=@SQL2012SPolitical,");
			strSql.Append("SCount=@SQL2012SCount,");
			strSql.Append("SPwd=@SQL2012SPwd,");
			strSql.Append("SEntryTime=@SQL2012SEntryTime,");
			strSql.Append("SUpdateTime=@SQL2012SUpdateTime,");
			strSql.Append("State=@SQL2012State,");
			strSql.Append("SNotIn=@SQL2012SNotIn");
			strSql.Append(" where Id=@SQL2012Id ");
			SqlParameter[] parameters = {
					new SqlParameter("@SQL2012SNo", SqlDbType.NVarChar,50),
					new SqlParameter("@SQL2012SName", SqlDbType.NVarChar,50),
					new SqlParameter("@SQL2012SClass", SqlDbType.NVarChar,50),
					new SqlParameter("@SQL2012SGender", SqlDbType.Char,10),
					new SqlParameter("@SQL2012SPhone", SqlDbType.NVarChar,11),
					new SqlParameter("@SQL2012SPolitical", SqlDbType.NVarChar,50),
					new SqlParameter("@SQL2012SCount", SqlDbType.Int,4),
					new SqlParameter("@SQL2012SPwd", SqlDbType.NVarChar,50),
					new SqlParameter("@SQL2012SEntryTime", SqlDbType.DateTime),
					new SqlParameter("@SQL2012SUpdateTime", SqlDbType.DateTime),
					new SqlParameter("@SQL2012State", SqlDbType.Int,4),
					new SqlParameter("@SQL2012SNotIn", SqlDbType.Int,4),
					new SqlParameter("@SQL2012Id", SqlDbType.UniqueIdentifier,16)};
			parameters[0].Value = model.SNo;
			parameters[1].Value = model.SName;
			parameters[2].Value = model.SClass;
			parameters[3].Value = model.SGender;
			parameters[4].Value = model.SPhone;
			parameters[5].Value = model.SPolitical;
			parameters[6].Value = model.SCount;
			parameters[7].Value = model.SPwd;
			parameters[8].Value = model.SEntryTime;
			parameters[9].Value = model.SUpdateTime;
			parameters[10].Value = model.State;
			parameters[11].Value = model.SNotIn;
			parameters[12].Value = model.Id;

			int rows=DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		/// <summary>
		/// 删除一条数据
		/// </summary>
		public bool Delete(Guid Id)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from tb_StuInfo ");
			strSql.Append(" where Id=@SQL2012Id ");
			SqlParameter[] parameters = {
					new SqlParameter("@SQL2012Id", SqlDbType.UniqueIdentifier,16)			};
			parameters[0].Value = Id;

			int rows=DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
        public bool Delete(string sno)
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from tb_StuInfo ");
            strSql.Append(" where SNo=@SQL2012SNo ");
            SqlParameter[] parameters = {
					new SqlParameter("@SQL2012SNo", SqlDbType.VarChar)};
            parameters[0].Value = sno;

            int rows = DbHelperSQL.ExecuteSql(strSql.ToString(), parameters);
            if (rows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
		/// <summary>
		/// 批量删除数据
		/// </summary>
		public bool DeleteList(string Idlist )
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from tb_StuInfo ");
			strSql.Append(" where Id in ("+Idlist + ")  ");
			int rows=DbHelperSQL.ExecuteSql(strSql.ToString());
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}


		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Model.tb_StuInfo GetModel(Guid Id)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1 Id,SNo,SName,SClass,SGender,SPhone,SPolitical,SCount,SPwd,SEntryTime,SUpdateTime,State,SNotIn from tb_StuInfo ");
			strSql.Append(" where Id=@SQL2012Id ");
			SqlParameter[] parameters = {
					new SqlParameter("@SQL2012Id", SqlDbType.UniqueIdentifier,16)			};
			parameters[0].Value = Id;

			Mayan.Model.tb_StuInfo model=new Mayan.Model.tb_StuInfo();
			DataSet ds=DbHelperSQL.Query(strSql.ToString(),parameters);
			if(ds.Tables[0].Rows.Count>0)
			{
				return DataRowToModel(ds.Tables[0].Rows[0]);
			}
			else
			{
				return null;
			}
		}

        public Model.tb_StuInfo GetModel(string username)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select  top 1 Id,SNo,SName,SClass,SGender,SPhone,SPolitical,SCount,SPwd,SEntryTime,SUpdateTime,State,SNotIn from tb_StuInfo ");
            strSql.Append(" where SNo=@SQL2012Name ");
            SqlParameter[] parameters = {
					new SqlParameter("@SQL2012Name", SqlDbType.VarChar)			};
            parameters[0].Value = username;

            Mayan.Model.tb_StuInfo model = new Mayan.Model.tb_StuInfo();
            DataSet ds = DbHelperSQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return DataRowToModel(ds.Tables[0].Rows[0]);
            }
            else
            {
                return null;
            }
        }

		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Model.tb_StuInfo DataRowToModel(DataRow row)
		{
			Mayan.Model.tb_StuInfo model=new Mayan.Model.tb_StuInfo();
			if (row != null)
			{
				if(row["Id"]!=null && row["Id"].ToString()!="")
				{
					model.Id= new Guid(row["Id"].ToString());
				}
				if(row["SNo"]!=null)
				{
					model.SNo=row["SNo"].ToString();
				}
				if(row["SName"]!=null)
				{
					model.SName=row["SName"].ToString();
				}
				if(row["SClass"]!=null)
				{
					model.SClass=row["SClass"].ToString();
				}
				if(row["SGender"]!=null)
				{
					model.SGender=row["SGender"].ToString();
				}
				if(row["SPhone"]!=null)
				{
					model.SPhone=row["SPhone"].ToString();
				}
				if(row["SPolitical"]!=null)
				{
					model.SPolitical=row["SPolitical"].ToString();
				}
				if(row["SCount"]!=null && row["SCount"].ToString()!="")
				{
					model.SCount=int.Parse(row["SCount"].ToString());
				}
				if(row["SPwd"]!=null)
				{
					model.SPwd=row["SPwd"].ToString();
				}
				if(row["SEntryTime"]!=null && row["SEntryTime"].ToString()!="")
				{
					model.SEntryTime=DateTime.Parse(row["SEntryTime"].ToString());
				}
				if(row["SUpdateTime"]!=null && row["SUpdateTime"].ToString()!="")
				{
					model.SUpdateTime=DateTime.Parse(row["SUpdateTime"].ToString());
				}
				if(row["State"]!=null && row["State"].ToString()!="")
				{
					model.State=int.Parse(row["State"].ToString());
				}
				if(row["SNotIn"]!=null && row["SNotIn"].ToString()!="")
				{
					model.SNotIn=int.Parse(row["SNotIn"].ToString());
				}
			}
			return model;
		}

		/// <summary>
		/// 获得数据列表
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select Id,SNo,SName,SClass,SGender,SPhone,SPolitical,SCount,SPwd,SEntryTime,SUpdateTime,State,SNotIn ");
			strSql.Append(" FROM tb_StuInfo ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获得前几行数据
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
			strSql.Append(" Id,SNo,SName,SClass,SGender,SPhone,SPolitical,SCount,SPwd,SEntryTime,SUpdateTime,State,SNotIn ");
			strSql.Append(" FROM tb_StuInfo ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获取记录总数
		/// </summary>
		public int GetRecordCount(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) FROM tb_StuInfo ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			object obj = DbHelperSQL.GetSingle(strSql.ToString());
			if (obj == null)
			{
				return 0;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("SELECT * FROM ( ");
			strSql.Append(" SELECT ROW_NUMBER() OVER (");
			if (!string.IsNullOrEmpty(orderby.Trim()))
			{
				strSql.Append("order by T." + orderby );
			}
			else
			{
				strSql.Append("order by T.Id desc");
			}
			strSql.Append(")AS Row, T.*  from tb_StuInfo T ");
			if (!string.IsNullOrEmpty(strWhere.Trim()))
			{
				strSql.Append(" WHERE " + strWhere);
			}
			strSql.Append(" ) TT");
			strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/*
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		{
			SqlParameter[] parameters = {
					new SqlParameter("SQL2012tblName", SqlDbType.VarChar, 255),
					new SqlParameter("SQL2012fldName", SqlDbType.VarChar, 255),
					new SqlParameter("SQL2012PageSize", SqlDbType.Int),
					new SqlParameter("SQL2012PageIndex", SqlDbType.Int),
					new SqlParameter("SQL2012IsReCount", SqlDbType.Bit),
					new SqlParameter("SQL2012OrderType", SqlDbType.Bit),
					new SqlParameter("SQL2012strWhere", SqlDbType.VarChar,1000),
					};
			parameters[0].Value = "tb_StuInfo";
			parameters[1].Value = "Id";
			parameters[2].Value = PageSize;
			parameters[3].Value = PageIndex;
			parameters[4].Value = 0;
			parameters[5].Value = 0;
			parameters[6].Value = strWhere;	
			return DbHelperSQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
		}*/

		#endregion  BasicMethod
		#region  ExtensionMethod

	    public DataTable GetRecordFromId(Guid Id)
	    {
	        DataTable dt = new DataTable();
	        StringBuilder str = new StringBuilder();
            str.Append("select s.Id,s.AName,s.AStartTime,s.AEndTime,s.ACharge,s.AWhere,t.IsHere from tb_Activity as s inner join tb_ActRecord as t on s.Id=t.ActivityId where s.Id in (select t.ActivityId from tb_ActRecord where t.StuId=@Id)");
	        SqlParameter para = new SqlParameter("@Id",Id);
	        dt = DbHelperSQL.Query(str.ToString(),para).Tables[0];
            return dt;
	    }



	    #endregion  ExtensionMethod
	}
}

