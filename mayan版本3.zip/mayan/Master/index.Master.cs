﻿using System;

namespace Mayan.Master
{
    public partial class index : System.Web.UI.MasterPage
    {
        static Model.tb_UserAdmin Model_Admin = null;
        private DAL.tb_UserAdmin Dal_Admin = new DAL.tb_UserAdmin();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["Admin"] == null)
                {
                    Response.Redirect("/admin/Login.aspx");
                }
                else
                {
                    Model_Admin = Session["Admin"] as Model.tb_UserAdmin;
                }
            }
        }

        protected void cacel_OnClick(object sender, EventArgs e)
        {
            Session["Admin"] = null;
            Response.Redirect("/admin/index.aspx");
        }

        protected void btn_confirm_OnClick(object sender, EventArgs e)
        {
            var password = Request["oldpsw"];
            var newpassword = Request["newpsw"];
            var newpsw2 = Request["newpsw2"];
            if (Model_Admin.Password != password)
            {
                Response.Write("<script>alert('原密码不正确！');</script>");
            }
            else if (newpassword != newpsw2)
            {
                Response.Write("<script>alert('两次密码不相同！');</script>");
            }
            else
            {
                Model_Admin.Password = newpassword;
                if (Dal_Admin.Update(Model_Admin))
                {
                    Response.Write("<script>alert('修改成功！');</script>");
                }
            }
        }
    }
}