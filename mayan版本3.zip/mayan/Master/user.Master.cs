﻿using System;

namespace Mayan.Master
{
    public partial class user : System.Web.UI.MasterPage
    {
        static Model.tb_StuInfo Model_Stu = null;
        private DAL.tb_StuInfo Dal_Stu = new DAL.tb_StuInfo();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["User"] == null)
                {
                    Response.Redirect("/index.aspx");
                }
                else
                {
                    Model_Stu = Session["User"] as Model.tb_StuInfo;
                }
            }
        }


        protected void confirm_OnClick(object sender, EventArgs e)
        {
            var password = Request["oldpsw"];
            var newpassword = Request["newpsw"];
            var newpsw2 = Request["newpsw2"];
            if (Model_Stu.SPwd != password)
            {
                Response.Write("<script>alert('原密码不正确！');</script>");
            }
            else if (newpassword != newpsw2)
            {
                Response.Write("<script>alert('两次密码不相同！');</script>");
            }
            else
            {
                Model_Stu.SPwd = newpassword;
                if (Dal_Stu.Update(Model_Stu))
                {
                    Response.Write("<script>alert('修改成功！');</script>");
                }
            }
        }

        protected void cacel_OnClick(object sender, EventArgs e)
        {
            Session["User"] = null;
            Response.Redirect("/index.aspx");
        }
    }
}