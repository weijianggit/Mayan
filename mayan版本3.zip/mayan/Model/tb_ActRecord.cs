﻿using System;
namespace Mayan.Model
{
	/// <summary>
	/// tb_ActRecord:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class tb_ActRecord
	{
		public tb_ActRecord()
		{}
		#region Model
		private Guid _id;
		private Guid _stuid;
		private Guid _activityid;
		private bool _ishere;
		private int? _state;
		/// <summary>
		/// 
		/// </summary>
		public Guid Id
		{
			set{ _id=value;}
			get{return _id;}
		}
		/// <summary>
		/// 
		/// </summary>
		public Guid StuId
		{
			set{ _stuid=value;}
			get{return _stuid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public Guid ActivityId
		{
			set{ _activityid=value;}
			get{return _activityid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public bool IsHere
		{
			set{ _ishere=value;}
			get{return _ishere;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? State
		{
			set{ _state=value;}
			get{return _state;}
		}
		#endregion Model

	}
}

