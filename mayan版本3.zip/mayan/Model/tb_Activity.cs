﻿/**  版本信息模板在安装目录下，可自行修改。
* tb_Activity.cs
*
* 功 能： N/A
* 类 名： tb_Activity
*
* Ver    变更日期             负责人  变更内容
* ───────────────────────────────────
* V0.01  2015/5/24 18:27:40   N/A    初版
*
* Copyright (c) 2012 Maticsoft Corporation. All rights reserved.
*┌──────────────────────────────────┐
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．　│
*│　版权所有：动软卓越（北京）科技有限公司　　　　　　　　　　　　　　│
*└──────────────────────────────────┘
*/
using System;
namespace Mayan.Model
{
	/// <summary>
	/// tb_Activity:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class tb_Activity
	{
		public tb_Activity()
		{}
		#region Model
		private Guid _id;
		private string _aname;
		private DateTime _astarttime;
		private DateTime _aendtime;
		private int _amaxno;
		private string _acharge;
		private string _awhere;
		private int _astuno=0;
		private int _state=0;
		private DateTime? _aentrytime;
		private DateTime? _aupdatetime;
		private string _apeople;
		/// <summary>
		/// 
		/// </summary>
		public Guid Id
		{
			set{ _id=value;}
			get{return _id;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string AName
		{
			set{ _aname=value;}
			get{return _aname;}
		}
		/// <summary>
		/// 
		/// </summary>
		public DateTime AStartTime
		{
			set{ _astarttime=value;}
			get{return _astarttime;}
		}
		/// <summary>
		/// 
		/// </summary>
		public DateTime AEndTime
		{
			set{ _aendtime=value;}
			get{return _aendtime;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int AMaxNo
		{
			set{ _amaxno=value;}
			get{return _amaxno;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string ACharge
		{
			set{ _acharge=value;}
			get{return _acharge;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string AWhere
		{
			set{ _awhere=value;}
			get{return _awhere;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int AStuNo
		{
			set{ _astuno=value;}
			get{return _astuno;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int State
		{
			set{ _state=value;}
			get{return _state;}
		}
		/// <summary>
		/// 
		/// </summary>
		public DateTime? AEntryTime
		{
			set{ _aentrytime=value;}
			get{return _aentrytime;}
		}
		/// <summary>
		/// 
		/// </summary>
		public DateTime? AUpdateTime
		{
			set{ _aupdatetime=value;}
			get{return _aupdatetime;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string APeople
		{
			set{ _apeople=value;}
			get{return _apeople;}
		}
		#endregion Model

	}
}

