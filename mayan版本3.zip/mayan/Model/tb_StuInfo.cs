﻿using System;
namespace Mayan.Model
{
	/// <summary>
	/// tb_StuInfo:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class tb_StuInfo
	{
		public tb_StuInfo()
		{}
		#region Model
		private Guid _id;
		private string _sno;
		private string _sname;
		private string _sclass;
		private string _sgender;
		private string _sphone;
		private string _spolitical;
		private int _scount=0;
		private string _spwd;
		private DateTime? _sentrytime;
		private DateTime? _supdatetime;
		private int? _state=0;
		private int? _snotin=0;
		/// <summary>
		/// 
		/// </summary>
		public Guid Id
		{
			set{ _id=value;}
			get{return _id;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string SNo
		{
			set{ _sno=value;}
			get{return _sno;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string SName
		{
			set{ _sname=value;}
			get{return _sname;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string SClass
		{
			set{ _sclass=value;}
			get{return _sclass;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string SGender
		{
			set{ _sgender=value;}
			get{return _sgender;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string SPhone
		{
			set{ _sphone=value;}
			get{return _sphone;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string SPolitical
		{
			set{ _spolitical=value;}
			get{return _spolitical;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int SCount
		{
			set{ _scount=value;}
			get{return _scount;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string SPwd
		{
			set{ _spwd=value;}
			get{return _spwd;}
		}
		/// <summary>
		/// 
		/// </summary>
		public DateTime? SEntryTime
		{
			set{ _sentrytime=value;}
			get{return _sentrytime;}
		}
		/// <summary>
		/// 
		/// </summary>
		public DateTime? SUpdateTime
		{
			set{ _supdatetime=value;}
			get{return _supdatetime;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? State
		{
			set{ _state=value;}
			get{return _state;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? SNotIn
		{
			set{ _snotin=value;}
			get{return _snotin;}
		}
		#endregion Model

	}
}

