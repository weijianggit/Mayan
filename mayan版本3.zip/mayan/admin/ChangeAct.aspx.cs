﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Mayan.Common;

namespace Mayan.admin
{
    public partial class ChangeAct : AuthAdmin
    {
        public static Model.tb_Activity Model_Act = null;
        private DAL.tb_Activity Dal_Act = new DAL.tb_Activity();

        protected void Page_Load(object sender, EventArgs e)
        {
            base.Page_Load(sender,e);
            var id = Request["Id"].ToString();
            if (id == "")
            {
                Response.Redirect("Login.aspx");
            }
            else
            {
                Model_Act = Dal_Act.GetModel(new Guid(id));
                if (Model_Act != null)
                {
                    Page.DataBind();
                }
                else
                {
                    Response.Redirect("/");
                }
            }
        }
        protected void LB_confirm_Click(object sender, EventArgs e)
        {
            var name = txt_name.Text.ToString();
            var starttime = txt_starttime.Text.ToString();
            var endtime = txt_endtime.Text.ToString();
            var maxno = txt_maxno.Text.ToString();
            var stuno = txt_stuno.Text.ToString();
            var charge = txt_charge.Text.ToString();
            var where = txt_where.Text.ToString();
            var people = txt_people.Text.ToString();
            var entrytime = txt_entry.Text.ToString();
            Model_Act.AName = name == "" ? Model_Act.AName : name;
            Model_Act.AStartTime = starttime == "" ? Model_Act.AStartTime : Convert.ToDateTime(starttime);
            Model_Act.AEndTime = endtime == "" ? Model_Act.AEndTime : Convert.ToDateTime(endtime);
            Model_Act.AMaxNo = maxno == "" ? Model_Act.AMaxNo : int.Parse(maxno);
            Model_Act.AStuNo = stuno == "" ? Model_Act.AStuNo : int.Parse(stuno);
            Model_Act.ACharge = charge == "" ? Model_Act.ACharge : charge;
            Model_Act.AWhere = where == "" ? Model_Act.AWhere : where;
            Model_Act.APeople = people == "" ? Model_Act.APeople : people;
            Model_Act.AUpdateTime = DateTime.Now;
            if (Dal_Act.Update(Model_Act))
            {
                Response.Write("<script>alert('更新成功！');</script>");
            }
            else
            {
                Response.Write("<script>alert('更新失败！');</script>");
            }
        }
    }
}