﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Mayan.Common;

namespace Mayan.admin
{
    public partial class ChangeInfo : AuthAdmin
    {
        public static Model.tb_StuInfo Model_Stu = null;
        public static Model.tb_StuInfo Model_Stu1 = new Model.tb_StuInfo();
        private DAL.tb_StuInfo Dal_Stu = new DAL.tb_StuInfo();

        protected void Page_Load(object sender, EventArgs e)
        {
            base.Page_Load(sender,e);
            var id = Request["Id"].ToString();
            if (!IsPostBack)
            {
                
           
            if (id == "")
            {
                Response.Redirect("Login.aspx");
            }
            else
            {
                    Model_Stu = Dal_Stu.GetModel(new Guid(id));
                    Model_Stu1 = Model_Stu;
                
                if (Model_Stu != null)
                {
                    Page.DataBind();
                }
                else
                {
                    Response.Redirect("/");
                }
            }
        }
        }

        protected void LB_confirm_Click(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                var sno = txt_sno.Text.ToString();
                var sname = txt_sname.Text.ToString();
                var sclass = txt_class.Text.ToString();
                var sgender = txt_gender.Text.ToString();
                var sphone = txt_phone.Text.ToString();
                var spolitical = txt_political.Text.ToString();
                var scount = txt_count.Text.ToString();
                var spwd = txt_pwd.Text.ToString();
                var sentry = txt_entry.Text.ToString();
                var supdate = txt_update.Text.ToString();
                var snotin = txt_notin.Text.ToString();
                Model_Stu1.SNo = sno == "" ? Model_Stu.SNo : sno;
                Model_Stu1.SName = sname == "" ? Model_Stu.SName : sname;
                Model_Stu1.SClass = sclass == "" ? Model_Stu.SClass : sclass;
                Model_Stu1.SGender = sgender == "" ? Model_Stu.SGender : sgender;
                Model_Stu1.SPhone = sphone == "" ? Model_Stu.SPhone : sphone;
                Model_Stu1.SPolitical = spolitical == "" ? Model_Stu.SPolitical : spolitical;
                Model_Stu1.SCount = scount == "" ? Model_Stu.SCount : int.Parse(scount);
                Model_Stu1.SPwd = spwd == "" ? Model_Stu.SPwd : spwd;
                Model_Stu1.SEntryTime = sentry == "" ? Model_Stu.SEntryTime : Convert.ToDateTime(sentry);
                Model_Stu1.SUpdateTime = DateTime.Now;
                Model_Stu1.SNotIn = snotin == "" ? Model_Stu.SNotIn : int.Parse(snotin);
            }
            if (Dal_Stu.Update(Model_Stu1))
            {
                Response.Write("<script>alert('更新成功！');window.location.href='StuInfo.aspx';</script>");

            }
            else
            {
                Response.Write("<script>alert('更新失败！');</script>");
            }
        }
    }
}