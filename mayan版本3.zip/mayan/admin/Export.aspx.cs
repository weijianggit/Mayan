﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Mayan.CommonHelper;
using NPOI.XSSF.UserModel;

namespace Mayan.admin
{
    public partial class Export : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void lb_download_OnClick(object sender, EventArgs e)
        {
            XSSFWorkbook hssfworkbook = null;
            string filepath = "../Common/example.xlsx";
            filepath = Server.MapPath(filepath);
            using (FileStream file = new FileStream(filepath, FileMode.Open, FileAccess.Read))
            {
                hssfworkbook = new XSSFWorkbook(file);
            }
            HttpContext context = HttpContext.Current;
            ExcelHelper.RenderToBrowser(hssfworkbook,context,"example.xlsx");
        }

        protected void lb_confirm_OnClick(object sender, EventArgs e)
        {
            Model.tb_StuInfo stu = null;
            DAL.tb_StuInfo d_stu = new DAL.tb_StuInfo();
            string path = string.Empty;
            if (fu_upload.HasFile)
            {
                string oldname = fu_upload.PostedFile.FileName;
                int index = oldname.LastIndexOf(".");
                string extisons = fu_upload.PostedFile.FileName.Substring(index);
                path = @"../Common/"+"1"+extisons;
                string[] allow_extension ={".xlsx",".xls"};
                if (allow_extension.Contains(extisons))
                {
                    fu_upload.SaveAs(Server.MapPath(path));
                    FileStream fs = new FileStream(Server.MapPath(path), FileMode.Open, FileAccess.Read);
                    DataTable dt = ExcelHelper.LeadingExcel(fs);
                    int count = 0;
                    foreach (DataRow dr in dt.Rows)
                    {
                        stu = new Model.tb_StuInfo();
                        stu.SNo = dr[0].ToString();
                        stu.SName = dr[1].ToString();
                        stu.SClass = dr[2].ToString();
                        stu.SGender = dr[3].ToString();
                        stu.SPhone = dr[4].ToString();
                        stu.SPolitical = dr[5].ToString();
                        stu.SCount = int.Parse(dr[6].ToString());
                        stu.SNotIn = int.Parse(dr[7].ToString());
                        stu.SPwd = stu.SNo;
                        stu.SEntryTime = DateTime.Now;
                        if (d_stu.Add(stu))
                        {
                            count++;
                        }
                    }
                    File.Delete(Server.MapPath(path));
                    Response.Write("<script>alert('成功插入" + count + "条记录');</script>");
                }
                else
                {
                    Response.Write("<script>alert('文件格式有误');</script>");
                }
            }
           
        }
    }
}