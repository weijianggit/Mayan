﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Mayan.admin
{
    public partial class Login : System.Web.UI.Page
    {
       private static Model.tb_UserAdmin Model_Admin = null;
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void login_button_Click(object sender, EventArgs e)
        {
            var username = Request.Form["username"].ToString();
            var password = Request.Form["password"].ToString();
            Model_Admin = CommonHelper.Helper.CheckAdminLogin(username, password);
            if (Model_Admin == null)
            {
                Response.Write("<script>alert('用户名或密码有误！');</script>");
            }
            else
            {
                Session["Admin"] = Model_Admin;
                Response.Redirect("StuInfo.aspx");
            }
        }
    }
}