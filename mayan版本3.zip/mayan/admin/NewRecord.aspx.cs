﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Web.UI.WebControls;
using Mayan.Common;
using System.Text.RegularExpressions;
namespace Mayan.admin
{
    public partial class NewRecord : AuthAdmin
    {
        private static Model.tb_Activity Model_Act = null;
        private DAL.tb_Activity Dal_Act = new DAL.tb_Activity();
        private static DAL.tb_StuInfo Dal_Stu = new DAL.tb_StuInfo();
        private DAL.tb_ActRecord Dal_Rec = new DAL.tb_ActRecord();

        private static DataTable dt = new DataTable();
        public static DataTable dt2 = Dal_Stu.GetList("").Tables[0].Clone();

        private static string sortstring = "DESC";
        private static List<string> ID =  new List<string>();

        protected void Page_Load(object sender, EventArgs e)
        {
            base.Page_Load(sender, e);
            if (!IsPostBack)
            {
                BindData();
            }
        }
        public void BindData()
        {
            dt = Dal_Stu.GetList("").Tables[0];
            GV_StuInfo.DataSource = dt.DefaultView;
            GV_StuInfo.DataKeyNames = new string[] { "Id" };
            GV_StuInfo.DataBind();
        }
        //筛选
        protected void select_OnClick(object sender, EventArgs e)
        {
            show.Visible = true;
            show_data.Visible = false;
        }
        //Gv_StuInfo事件，Gv_StuInfo为第一个gridview,第二个为Gv_Add
        protected void GV_StuInfo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        protected void GV_StuInfo_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            this.GV_StuInfo.PageIndex = e.NewPageIndex;
            BindData();
        }
        protected void GV_StuInfo_Sorting(object sender, GridViewSortEventArgs e)
        {
            DataView dv = new DataView(dt);
            if (sortstring == "DESC")
            {
                dv.Sort = e.SortExpression + " ASC";
                sortstring = "ASC";
            }
            else
            {
                dv.Sort = e.SortExpression + " DESC";
                sortstring = "DESC";
            }
            GV_StuInfo.DataSource = dv;
            GV_StuInfo.DataBind();
        }

        //搜索框确认
        protected void btn_confirm_Click(object sender, EventArgs e)
        {
            string txt_class = txt_Class.Text.Trim();
            string txt_political = txt_Political.Text.Trim();

            string txt_notIn = txt_NotIn.Text.Trim();

            dt = Dal_Stu.GetList("").Tables[0];
            DataView dv = dt.DefaultView;
            dv.RowFilter = "1=1";
            if (txt_class != "")
            {
                dv.RowFilter += " and SClass like '%" + txt_class + "%'";
            }
            if (txt_political != "")
            {
                dv.RowFilter += "and SPolitical like '%" + txt_political + "%'";
            }
            if (txt_Count.Text != "")
            {
                int txt_count = Int32.Parse(txt_Count.Text);
                dv.RowFilter += "and SCount=" + txt_count + "";
            }
            if (txt_NotIn.Text != "")
            {
                int txt_notin = Int32.Parse(txt_NotIn.Text);
                dv.RowFilter += "and SNotIn=" + txt_notin + "";
            }
            GV_StuInfo.DataSource = dv;
            GV_StuInfo.DataBind();
        }

        //全选按钮
        protected void CheckOne_OnCheckedChanged(object sender, EventArgs e)
        {
            if ((GV_StuInfo.HeaderRow.FindControl("CheckOne") as CheckBox).Checked == true)
            {
                foreach (GridViewRow gr in GV_StuInfo.Rows)
                {
                    (gr.FindControl("CheckTwo") as CheckBox).Checked = true;
                }
            }
            else
            {
                foreach (GridViewRow gr in GV_StuInfo.Rows)
                {
                    (gr.FindControl("CheckTwo") as CheckBox).Checked = false;
                }
            }
        }

        protected void GV_Add_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            this.GV_Add.PageIndex = e.NewPageIndex;
            add_databind();

        }
        public void add_databind()
        {
            GV_Add.DataSource = dt2;
            GV_Add.DataBind();
        }
        //确认添加
        protected void confirm_OnClick(object sender, EventArgs e)
        {
            //dt2 = Dal_Stu.GetList("").Tables[0].Clone();
            
            foreach (GridViewRow gr in GV_StuInfo.Rows)
            {
                if ((gr.FindControl("CheckTwo") as CheckBox).Checked == true)
                {
                    string key = gr.Cells[1].Text.ToString().Trim();
                    string datakey = GV_StuInfo.DataKeys[gr.RowIndex].Value.ToString();
                    ID.Add(datakey);
                    DataTable dt3 = Dal_Stu.GetList("Id = '" + new Guid(GV_StuInfo.DataKeys[gr.RowIndex].Value.ToString()) + "'").Tables[0];
                    dt2.Rows.Add(dt3.Rows[0].ItemArray);
                }
            }

            GV_Add.DataKeyNames = new string[] { "Id" };
            add_databind();
            show.Visible = true;
            show_data.Visible = true;
        }

        //最后一个确认键
        protected void OK_OnClick(object sender, EventArgs e)
        {
            Model_Act = new Model.tb_Activity();
            Model_Act.Id = Guid.NewGuid();
            Model_Act.AName = txtname.Text;
            /*string r1 = "^[0-9]{4}[-][0-9]{2}[-][0-9]{2}$";
             string start = txtstarttime.Text.ToString();
             string end = txtendtime.Text.ToString();
             if (Regex.IsMatch(start, r1) && Regex.IsMatch(end, r1))
             {
                 Model_Act.AStartTime = Convert.ToDateTime(txtstarttime.Text);
                 Model_Act.AEndTime = Convert.ToDateTime(txtendtime.Text);
             }*/

            char[] separate={'-'};
            string[] a = txtstarttime.Text.ToString().Split(separate);
            if (a[0].Length!=4)
            {
                Response.Write("<script>alert('请输入正确的日期格式！');window.location.href='NewRecord.aspx'</script>");
            }
            Model_Act.AStartTime = Convert.ToDateTime(txtstarttime.Text);
            Model_Act.AEndTime = Convert.ToDateTime(txtendtime.Text);
            Model_Act.AMaxNo = int.Parse(txtmaxno.Text);
            Model_Act.AStuNo = 0;
            Model_Act.AWhere = txtwhere.Text.Trim();
            Model_Act.APeople = txtpeople.Text.Trim();
            //           Model_Act.ACharge = txtcharger.Text;
            Model_Act.AEntryTime = DateTime.Now;
            if (Dal_Act.Add(Model_Act))
            {
                int count = 0;
                while (ID.Count == 0)
                {
                    Response.Write("<script>alert('请选择对象!');</script>");
                }
                for (int i = 0; i < ID.Count; i++)
                {
                    Model.tb_ActRecord model = new Model.tb_ActRecord();
                    model.Id = Guid.NewGuid();
                    model.StuId = new Guid(ID[i].ToString());
                    model.ActivityId = Model_Act.Id;
                    count++;
                    if (!Dal_Rec.Add(model))
                    {
                        break;
                    }
                }
                if (count < ID.Count)
                {
                    Response.Write("<script>alert('添加失败！');</script>");
                    Dal_Act.Delete(Model_Act.Id);
                }
                else
                {
                    dt2 = Dal_Stu.GetList("").Tables[0].Clone();
                    ID = new List<string>();
                    Response.Write("<script>alert('添加成功！');window.location.href='StuRecord.aspx'</script>");
                }

            }
        }




    }
}