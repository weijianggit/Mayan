﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Mayan.Common;

namespace Mayan.admin
{
    public partial class NewStuInfo : AuthAdmin
    {
        public static Model.tb_StuInfo Model_Stu = new Model.tb_StuInfo();
        private DAL.tb_StuInfo Dal_Stu = new DAL.tb_StuInfo();
        protected void  Page_Load(object sender, EventArgs e)
        {
            base.Page_Load(sender,e);
        }
        protected void LB_confirm_Click(object sender, EventArgs e)
        {
            var sno = txt_sno.Text.ToString();
            var sname = txt_sname.Text.ToString();
            var sclass = txt_class.Text.ToString();
            var sgender = txt_gender.Text.ToString();
            var sphone = txt_phone.Text.ToString();
            var spolitical = txt_political.Text.ToString();
            var scount = txt_count.Text.ToString();
            var spwd = txt_pwd.Text.ToString();
            var snotin = txt_notin.Text.ToString();
            Model_Stu.SNo = sno == "" ? Model_Stu.SNo : sno;
            Model_Stu.SName = sname == "" ? Model_Stu.SName : sname;
            Model_Stu.SClass = sclass == "" ? Model_Stu.SClass : sclass;
            Model_Stu.SGender = sgender == "" ? Model_Stu.SGender : sgender;
            Model_Stu.SPhone = sphone == "" ? Model_Stu.SPhone : sphone;
            Model_Stu.SPolitical = spolitical == "" ? Model_Stu.SPolitical : spolitical;
            Model_Stu.SCount = scount == "" ? Model_Stu.SCount : int.Parse(scount);
            Model_Stu.SPwd = spwd == "" ? Model_Stu.SPwd : spwd;
            Model_Stu.SEntryTime = DateTime.Now;
            Model_Stu.SNotIn = snotin == "" ? Model_Stu.SNotIn : int.Parse(snotin);
            if (Dal_Stu.Add(Model_Stu))
            {
                Response.Write("<script>alert('添加成功！');window.location.href = 'StuInfo.aspx';</script>");
            }
            else
            {
                Response.Write("<script>alert('添加失败！');window.location.href = 'StuInfo.aspx';</script>");
            }
         
        }
    }
}