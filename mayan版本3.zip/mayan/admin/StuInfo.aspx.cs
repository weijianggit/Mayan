﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Mayan.Common;

namespace Mayan.admin
{
    public partial class StuInfo : AuthAdmin
    {
        private DAL.tb_StuInfo Dal_Stu = new DAL.tb_StuInfo();
        private static DataTable dt = new DataTable();
        private static string sortstring = "DESC";
        protected void Page_Load(object sender, EventArgs e)
        {
            base.Page_Load(sender,e);
            if (!IsPostBack)
            {
              BindData();  
            }
            
        }

        protected void GV_StuInfo_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            this.GV_StuInfo.PageIndex = e.NewPageIndex;
            BindData();
        }
        public void BindData()
        {
            dt = Dal_Stu.GetList("").Tables[0];
            GV_StuInfo.DataSource = dt.DefaultView;
            GV_StuInfo.DataKeyNames = new string[] { "Id" };
            GV_StuInfo.DataBind();
        }
        protected void GV_StuInfo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GV_StuInfo_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            string SNo =GV_StuInfo.Rows[e.RowIndex].Cells[0].Text.ToString();
            if (Dal_Stu.Delete(SNo))
            {
                Response.Write("<script>alert('删除成功');</script>");
            }
            BindData();
        }

        protected void btn_confirm_Click(object sender, EventArgs e)
        {
            string txt_class = txt_Class.Text;
            string txt_political = txt_Political.Text;
            dt = Dal_Stu.GetList("").Tables[0];
            DataView dv = dt.DefaultView;
            dv.RowFilter = "1=1";
            if (txt_class != "")
            {
                dv.RowFilter += " and SClass like '%" + txt_class + "%'";
            }
            if (txt_political != "")
            {
                dv.RowFilter += "and SPolitical like '%" + txt_political + "%'";
            }
            if (txt_Count.Text != "")
            {
                int txt_count = Int32.Parse(txt_Count.Text);
                dv.RowFilter += "and SCount=" + txt_count + "";
            }
            if (txt_NotIn.Text != "")
            {
                int txt_notin = Int32.Parse(txt_NotIn.Text);
                dv.RowFilter += "and SNotIn=" + txt_notin + "";
            }
            GV_StuInfo.DataSource = dv;
            GV_StuInfo.DataBind();
        }

        protected void GV_StuInfo_RowEditing(object sender, GridViewEditEventArgs e)
        {
            var id = GV_StuInfo.DataKeys[e.NewEditIndex].Values[0].ToString();
            Response.Redirect("ChangeInfo.aspx?Id="+id);
        }

        protected void GV_StuInfo_Sorting(object sender, GridViewSortEventArgs e)
        {
            DataView dv = new DataView(dt);
            if (sortstring == "DESC")
            {
                dv.Sort = e.SortExpression + " ASC";
                sortstring = "ASC";
            }
            else
            {
                dv.Sort = e.SortExpression + " DESC";
                sortstring = "DESC";
            }
            GV_StuInfo.DataSource = dv;
            GV_StuInfo.DataBind();
        }

        protected void LB_Insert_OnClick(object sender, EventArgs e)
        {
            Response.Redirect("NewStuInfo.aspx");
        }
    }
}