﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Mayan.Common;

namespace Mayan.admin
{
    public partial class StuRecord : AuthAdmin
    {
        private static Model.tb_Activity Model_Act = null;//大记录，，record小记录
        private DAL.tb_Activity Dal_Act = new DAL.tb_Activity();
        private static DataTable dt = new DataTable();
        private static DataTable dt2 = new DataTable();
        private static string sortstring = "DESC";
        private static string id = string.Empty;//activity id,string
        private static string little_actid;//stu_id
        private static Guid id1;
        protected void Page_Load(object sender, EventArgs e)
        {
            base.Page_Load(sender, e);
            if (!IsPostBack)
            {
                BindData();
            }
        }

        private void BindData()
        {
            dt = Dal_Act.GetList("").Tables[0];
            GV_Act.DataSource = dt.DefaultView;
            GV_Act.DataKeyNames = new string[] {"Id"};
            GV_Act.DataBind();
        }

        protected void GV_Act_Sorting(object sender, GridViewSortEventArgs e)
        {

        }

        protected void GV_Act_RowEditing(object sender, GridViewEditEventArgs e)
        {
            int i = e.NewEditIndex;
            id1 = (Guid)GV_Act.DataKeys[i].Value;
            id = GV_Act.DataKeys[e.NewEditIndex].Values[0].ToString();
            Response.Redirect("ChangeAct.aspx?Id=" + id);
        }

        protected void GV_Act_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            var id = GV_Act.DataKeys[e.RowIndex].Values[0].ToString();

            if (Dal_Act.Delete(new Guid(id)))
            {
                Response.Write("<script>alert('删除成功');</script>");
            }
            Stu.Visible = false;
            BindData();
        }

        protected void GV_Act_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            this.GV_Act.PageIndex = e.NewPageIndex;
            BindData();
        }
        protected void GV_Act_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            id = e.CommandArgument.ToString();
            switch (e.CommandName)
            {
                case "Show":
                    Stu.Visible = true;
                    BindInfo(id);
                    break;
                default:
                    break;
            }
        }

        protected void GV_StuInfo_Sorting(object sender, GridViewSortEventArgs e)
        {
            DataView dv = new DataView(dt2);
            if (sortstring == "DESC")
            {
                dv.Sort = e.SortExpression + " ASC";
                sortstring = "ASC";
            }
            else
            {
                dv.Sort = e.SortExpression + " DESC";
                sortstring = "DESC";
            }
            GV_StuInfo.DataSource = dv;
            GV_StuInfo.DataBind();
        }

        protected void GV_StuInfo_RowEditing(object sender, GridViewEditEventArgs e)
        {
            Change.Visible = true;
            int i=e.NewEditIndex;
            var sno = GV_StuInfo.Rows[e.NewEditIndex].Cells[0].Text;
            var sname = GV_StuInfo.Rows[e.NewEditIndex].Cells[1].Text;
            var snotin = GV_StuInfo.Rows[e.NewEditIndex].Cells[11].Text;
            little_actid = GV_StuInfo.DataKeys[i].Value.ToString();
            Lb_Sno.Text = sno;
            Lb_Sname.Text = sname;
            ddlin.SelectedIndex = snotin.Equals("false", StringComparison.OrdinalIgnoreCase) ? 1 : 0;
            e.Cancel = true;
        }

        private void BindInfo(string id)
        {
            dt2 = Dal_Act.GetActStu(new Guid(id));
            GV_StuInfo.DataSource = dt2.DefaultView;
            GV_StuInfo.DataKeyNames = new string[] { "Id" };
            GV_StuInfo.DataBind();
        }

        protected void Update_OnClick(object sender, EventArgs e)
        {
            var snotin = ddlin.SelectedValue;
            DAL.tb_ActRecord act = new DAL.tb_ActRecord();
            Model.tb_ActRecord model = act.GetModel2(new Guid(id),new Guid(little_actid));
            model.IsHere = snotin=="true"?true:false;
            act.Update(model);
            BindInfo(id);
        }

        protected void GV_StuInfo_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        protected void GV_Act_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        protected void Show_Click(object sender, EventArgs e)
        {

        }

        protected void GV_StuInfo_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            this.GV_StuInfo.PageIndex = e.NewPageIndex;
            BindInfo(id);
        }


    }
}