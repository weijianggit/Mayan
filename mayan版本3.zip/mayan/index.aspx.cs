﻿using System;

namespace Mayan
{
    public partial class index : System.Web.UI.Page
    {
        Model.tb_StuInfo Model_Stu = null;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void login_button_Click(object sender, EventArgs e)
        {
            var username = Request.Form["username"].ToString();
            var password = Request.Form["password"].ToString();
            Model_Stu = CommonHelper.Helper.CheckLogin(username,password);
            if (Model_Stu == null)
            {
                Response.Write("<script>alert('用户名或密码有误！');</script>");
            }
            else
            {
                Session["User"] = Model_Stu;
                Response.Redirect("user/index.aspx");
            }
        }
    }
}