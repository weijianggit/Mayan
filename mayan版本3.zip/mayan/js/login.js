// JavaScript Document
$(document).ready(function(e) {
	$(".inputBox input").focus(function(e) {
        $(this).parent().css("border","1px #4892e7 solid");
		$(this).siblings("label").css("color","#ccc");
    });
	$(".inputBox input").blur(function(e) {
        $(this).parent().css("border","1px #ccc solid");
		$(this).siblings("label").css("color","#aaa");
    });
});
$(function(){
	$(".inputBox input").keydown(function(e) {
        $(this).siblings("label").css("display","none");
    });
	$(".inputBox input").keyup(function(e) {
        if($(this).val()==""){
            $(this).siblings("label").css("display","block");
		}
    });
});
$(function() {
    $('.fgtpsw').click(function() {
        $('#pop').show();
        return false;
    });
    $('#Button').click(function() {
        $('#pop').hide();
        return false;
    });
})
window.onload=function(){
  function isIE(){ 
    if(!!window.ActiveXObject || "ActiveXObject" in window){ 
      return true; 
    }   
    else{ 
     return false; 
    } 
  } 
  (function(){ 
    var inputPWD=document.getElementById('password'); 
    var capital=false; 
    var capitalTip={ 
      elem:document.getElementById('capsLock'), 
      toggle:function(s){ 
        var sy=this.elem.style; 
        var d=sy.display; 
        if(s){ 
          sy.display = s; 
        }
        else{ 
          sy.display=d=='none'?'':'none'; 
        } 
      } 
    } 
    var detectCapsLock=function(event){ 
      if(capital){return}; 
      var e = event||window.event; 
      var keyCode = e.keyCode||e.which;
      var isShift = e.shiftKey ||(keyCode == 16 ) || false ;
      if(((keyCode>=65&&keyCode<=90 )&&!isShift)||((keyCode>=97&&keyCode<=122 )&&isShift)){
        capitalTip.toggle('block');
        capital=true
      } 
      else{
        capitalTip.toggle('none');
      } 
    } 
    if(!isIE()){
      inputPWD.onkeypress=detectCapsLock; 
      inputPWD.onkeyup=function(event){ 
        var e = event||window.event; 
        if(e.keyCode == 20 && capital){ 
          capitalTip.toggle(); 
          return false; 
        } 
      } 
   }
  })()
}