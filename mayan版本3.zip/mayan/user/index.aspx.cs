﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Mayan.user
{
    public partial class index : System.Web.UI.Page
    {
        static Model.tb_StuInfo Model_Stu = null;
        DAL.tb_StuInfo Dal_Stu = new DAL.tb_StuInfo();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                if (Session["user"] == null)
                {
                    Response.Redirect("/index.aspx");
                }
                else
                {
                    Model_Stu = Session["user"] as Model.tb_StuInfo;
                    Bind(Model_Stu);
                }
            }
        }

        protected void FV_Info_ModeChanging(object sender, FormViewModeEventArgs e)
        {

        }

        protected void FV_Info_ItemUpdating(object sender, FormViewUpdateEventArgs e)
        {
            var sno = (FV_Info.FindControl("txtSNo") as TextBox).Text.ToString();
            var sname = (FV_Info.FindControl("txtName") as TextBox).Text.ToString();
            var sclass = (FV_Info.FindControl("txtClass") as TextBox).Text.ToString();
            var sgender = (FV_Info.FindControl("txtGender") as TextBox).Text.ToString();
            var sphone = (FV_Info.FindControl("txtPhone") as TextBox).Text.ToString();
            Model_Stu.SNo = sno == "" ? Model_Stu.SNo : sno;
            Model_Stu.SName = sname== "" ? Model_Stu.SName : sname;
            Model_Stu.SClass = sclass == "" ? Model_Stu.SClass : sclass;
            Model_Stu.SGender = sgender == "" ? Model_Stu.SGender : sgender;
            Model_Stu.SPhone = sphone == "" ? Model_Stu.SPhone : sphone;
            Model_Stu.SUpdateTime = DateTime.Now;
            if (Dal_Stu.Update(Model_Stu))
            {
                Response.Write("<script>alert('修改成功');</script>");
            }
        }

        private void Bind(Model.tb_StuInfo model)
        {
            StringBuilder str = new StringBuilder();
            str.Append("select * from tb_StuInfo where Id='"+model.Id+"'");
            DataTable dt = CommonHelper.DbHelperSQL.Query(str.ToString()).Tables[0];
            if (dt.Rows.Count>0)
            {
                FV_Info.DataSource = dt;
                FV_Info.DataKeyNames=new string[] {"Id"};
                FV_Info.DataBind();
            }
        }

        protected void Change_OnClick(object sender, EventArgs e)
        {
            FV_Info.ChangeMode(FormViewMode.Edit);
            Bind(Model_Stu);
        }

        protected void Cancel_OnClick(object sender, EventArgs e)
        {
           FV_Info.ChangeMode(FormViewMode.ReadOnly);
            Bind(Model_Stu);
        }
    }
}