﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Mayan.user
{
    public partial class record : System.Web.UI.Page
    {
        private DAL.tb_StuInfo Dal_Stu = new DAL.tb_StuInfo();
        private static Model.tb_StuInfo Model_Stu = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["User"] == null)
                {
                    Response.Redirect("/index,aspx");
                }
                else
                {
                    Model_Stu = Session["User"] as Model.tb_StuInfo;
                    Bind(Model_Stu.Id);
                }
            }
        }

        private void Bind(Guid Id)
        {
            DataTable dt = new DataTable();
            dt = Dal_Stu.GetRecordFromId(Id);
            GV_Act.DataSource = dt;
            GV_Act.DataKeyNames = new string[] {"Id"};
            GV_Act.DataBind();
        }
    }
}